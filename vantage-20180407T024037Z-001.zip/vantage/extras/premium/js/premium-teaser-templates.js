/**
 * (c) Greg Priday, freely distributable under the terms of the GPL 2.0 license.
 */

jQuery(function($){
    $('#page_template' ).after(siteoriginTeaserTemplates.code);
});