<h3><?php _e( 'Forever Free', 'vantage' ) ?></h3>
<p>
	<?php _e( "Vantage is a completely free WordPress theme.", 'vantage' ) ?>
	<?php _e( "We'll continue developing and enhancing it for years to come.", 'vantage' ) ?>
</p>