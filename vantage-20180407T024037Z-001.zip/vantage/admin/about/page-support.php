<h3><?php _e( 'Lightning Fast Support', 'vantage' ) ?></h3>
<p>
	<?php printf( __( "As a Vantage Premium user, you'll get fast, friendly support through %semail%s.", 'vantage' ), '<a href="mailto:support@siteorigin.com">', '</a>' ) ?>
	<?php printf( __( "You can also read through the %sVantage documentation%s to get to know it even faster.", 'vantage' ), '<a href="https://siteorigin.com/vantage-documentation/">', '</a>' ) ?>
</p>