<?php
return json_decode( '{
	"77e88891e4965161953320ec66623cbc": {
		"name": "Greg Priday",
		"email": "77e88891e4965161953320ec66623cbc",
		"loc": 26867,
		"score": 2072.2396424979347,
		"percent": 80.15821036339706
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 3072,
		"score": 344.92071674303594,
		"percent": 13.342195952806904
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 3695,
		"score": 154.4071394623897,
		"percent": 5.972764786854983
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 254,
		"score": 12.465450556026019,
		"percent": 0.48218757495633346
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 33,
		"score": 0.9328779538745156,
		"percent": 0.03608551141310548
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 7,
		"score": 0.22118370357543934,
		"percent": 0.008555810571591745
	}
}', true );